REDLINE CUP — Standoff 2 tournament site prototype

Open index.html in a browser.

Included:
- Responsive black/red tournament landing page
- Registration form for 5-player teams
- Local demo organizer panel (demo code: 2026)
- Approve/reject-like status toggling, 8 approved slots, CSV export

Important limitations:
- This is a static prototype. Registrations are saved in the browser's localStorage only.
- Different visitors' submissions will NOT reach the organizer automatically.
- The demo organizer code is not secure and is visible in the source.
- Before public launch, connect a backend/database or use a hosted form service.
- Prize amount, schedule, rules, contact details and payout terms need to be filled in before announcing the event.
